--
-- PostgreSQL database dump
--

\restrict Okuj8ch3Fc91wzfoGuhnA3KHpajAsTbN0b2ORYJCo8Cs62sngQhBp3f3J050SV4

-- Dumped from database version 14.24 (Ubuntu 14.24-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.24 (Ubuntu 14.24-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.wallets DROP CONSTRAINT IF EXISTS wallets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_wallet_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_scratch_progress DROP CONSTRAINT IF EXISTS user_scratch_progress_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_scratch_progress DROP CONSTRAINT IF EXISTS user_scratch_progress_lesson_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_scratch_progress DROP CONSTRAINT IF EXISTS user_scratch_progress_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_daily_spins DROP CONSTRAINT IF EXISTS user_daily_spins_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_daily_quests DROP CONSTRAINT IF EXISTS user_daily_quests_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_daily_quests DROP CONSTRAINT IF EXISTS user_daily_quests_quest_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_achievements DROP CONSTRAINT IF EXISTS user_achievements_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_achievements DROP CONSTRAINT IF EXISTS user_achievements_achievement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.scratch_lessons DROP CONSTRAINT IF EXISTS scratch_lessons_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchases DROP CONSTRAINT IF EXISTS purchases_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchases DROP CONSTRAINT IF EXISTS purchases_game_id_fkey;
ALTER TABLE IF EXISTS ONLY public.login_reward_claims DROP CONSTRAINT IF EXISTS login_reward_claims_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.games DROP CONSTRAINT IF EXISTS games_creator_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attempts DROP CONSTRAINT IF EXISTS attempts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.attempts DROP CONSTRAINT IF EXISTS attempts_game_id_fkey;
DROP INDEX IF EXISTS public.ix_wallet_transactions_wallet_user_id;
DROP INDEX IF EXISTS public.ix_wallet_transactions_created_at;
DROP INDEX IF EXISTS public.ix_users_xp;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_users_streak;
DROP INDEX IF EXISTS public.ix_users_role;
DROP INDEX IF EXISTS public.ix_users_grade;
DROP INDEX IF EXISTS public.ix_user_scratch_progress_user_id;
DROP INDEX IF EXISTS public.ix_user_daily_spins_user_id;
DROP INDEX IF EXISTS public.ix_user_daily_spins_spin_date;
DROP INDEX IF EXISTS public.ix_user_daily_quests_user_id;
DROP INDEX IF EXISTS public.ix_user_daily_quests_status;
DROP INDEX IF EXISTS public.ix_user_daily_quests_quest_id;
DROP INDEX IF EXISTS public.ix_user_daily_quests_quest_date;
DROP INDEX IF EXISTS public.ix_user_achievements_user_id;
DROP INDEX IF EXISTS public.ix_purchases_user_id;
DROP INDEX IF EXISTS public.ix_purchases_game_id;
DROP INDEX IF EXISTS public.ix_login_reward_claims_user_id;
DROP INDEX IF EXISTS public.ix_login_reward_claims_claim_date;
DROP INDEX IF EXISTS public.ix_games_template_code;
DROP INDEX IF EXISTS public.ix_games_review_status;
DROP INDEX IF EXISTS public.ix_games_rating_avg;
DROP INDEX IF EXISTS public.ix_games_price;
DROP INDEX IF EXISTS public.ix_games_is_published;
DROP INDEX IF EXISTS public.ix_games_grade_to;
DROP INDEX IF EXISTS public.ix_games_grade_from;
DROP INDEX IF EXISTS public.ix_games_creator_id;
DROP INDEX IF EXISTS public.ix_games_created_at;
DROP INDEX IF EXISTS public.ix_games_category;
DROP INDEX IF EXISTS public.ix_game_categories_sort_order;
DROP INDEX IF EXISTS public.ix_game_categories_is_active;
DROP INDEX IF EXISTS public.ix_daily_quests_type;
DROP INDEX IF EXISTS public.ix_attempts_user_id;
DROP INDEX IF EXISTS public.ix_attempts_score;
DROP INDEX IF EXISTS public.ix_attempts_game_id;
DROP INDEX IF EXISTS public.ix_attempts_created_at;
ALTER TABLE IF EXISTS ONLY public.wallets DROP CONSTRAINT IF EXISTS wallets_pkey;
ALTER TABLE IF EXISTS ONLY public.wallet_transactions DROP CONSTRAINT IF EXISTS wallet_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_scratch_progress DROP CONSTRAINT IF EXISTS user_scratch_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.user_daily_spins DROP CONSTRAINT IF EXISTS user_daily_spins_pkey;
ALTER TABLE IF EXISTS ONLY public.user_daily_quests DROP CONSTRAINT IF EXISTS user_daily_quests_pkey;
ALTER TABLE IF EXISTS ONLY public.user_achievements DROP CONSTRAINT IF EXISTS user_achievements_pkey;
ALTER TABLE IF EXISTS ONLY public.user_daily_spins DROP CONSTRAINT IF EXISTS uq_user_daily_spin_day;
ALTER TABLE IF EXISTS ONLY public.user_daily_quests DROP CONSTRAINT IF EXISTS uq_user_daily_quest_day;
ALTER TABLE IF EXISTS ONLY public.login_reward_claims DROP CONSTRAINT IF EXISTS uq_login_reward_user_day;
ALTER TABLE IF EXISTS ONLY public.scratch_lessons DROP CONSTRAINT IF EXISTS scratch_lessons_pkey;
ALTER TABLE IF EXISTS ONLY public.scratch_courses DROP CONSTRAINT IF EXISTS scratch_courses_pkey;
ALTER TABLE IF EXISTS ONLY public.purchases DROP CONSTRAINT IF EXISTS purchases_pkey;
ALTER TABLE IF EXISTS ONLY public.login_reward_claims DROP CONSTRAINT IF EXISTS login_reward_claims_pkey;
ALTER TABLE IF EXISTS ONLY public.games DROP CONSTRAINT IF EXISTS games_pkey;
ALTER TABLE IF EXISTS ONLY public.game_categories DROP CONSTRAINT IF EXISTS game_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.daily_quests DROP CONSTRAINT IF EXISTS daily_quests_pkey;
ALTER TABLE IF EXISTS ONLY public.attempts DROP CONSTRAINT IF EXISTS attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.achievements DROP CONSTRAINT IF EXISTS achievements_pkey;
ALTER TABLE IF EXISTS public.scratch_lessons ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.purchases ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS public.wallets;
DROP TABLE IF EXISTS public.wallet_transactions;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_scratch_progress;
DROP TABLE IF EXISTS public.user_daily_spins;
DROP TABLE IF EXISTS public.user_daily_quests;
DROP TABLE IF EXISTS public.user_achievements;
DROP SEQUENCE IF EXISTS public.scratch_lessons_id_seq;
DROP TABLE IF EXISTS public.scratch_lessons;
DROP TABLE IF EXISTS public.scratch_courses;
DROP SEQUENCE IF EXISTS public.purchases_id_seq;
DROP TABLE IF EXISTS public.purchases;
DROP TABLE IF EXISTS public.login_reward_claims;
DROP TABLE IF EXISTS public.games;
DROP TABLE IF EXISTS public.game_categories;
DROP TABLE IF EXISTS public.daily_quests;
DROP TABLE IF EXISTS public.attempts;
DROP TABLE IF EXISTS public.achievements;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: achievements; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.achievements (
    id character varying(30) NOT NULL,
    title character varying(150) NOT NULL,
    description character varying(255),
    badge_code character varying(50),
    xp_bonus integer,
    icon character varying(20)
);


ALTER TABLE public.achievements OWNER TO iqkids_user;

--
-- Name: attempts; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.attempts (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    game_id character varying(80) NOT NULL,
    level_num integer NOT NULL,
    score integer,
    completed boolean,
    duration_secs integer,
    created_at timestamp without time zone
);


ALTER TABLE public.attempts OWNER TO iqkids_user;

--
-- Name: daily_quests; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.daily_quests (
    id character varying(50) NOT NULL,
    title character varying(150) NOT NULL,
    description character varying(255) NOT NULL,
    type character varying(40) NOT NULL,
    target_count integer NOT NULL,
    xp_reward integer,
    coin_reward integer,
    is_active boolean NOT NULL
);


ALTER TABLE public.daily_quests OWNER TO iqkids_user;

--
-- Name: game_categories; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.game_categories (
    code character varying(50) NOT NULL,
    label character varying(150) NOT NULL,
    icon character varying(20),
    description text,
    sort_order integer,
    is_active boolean,
    created_at timestamp without time zone
);


ALTER TABLE public.game_categories OWNER TO iqkids_user;

--
-- Name: games; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.games (
    id character varying(80) NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    detailed_description text,
    thumbnail character varying(20),
    price integer,
    grade_from integer,
    grade_to integer,
    template_code character varying(50) NOT NULL,
    category character varying(50),
    creator_id character varying(50),
    creator_name character varying(150),
    review_status character varying(30),
    review_feedback text,
    is_published boolean,
    is_seed boolean,
    rating_avg double precision,
    plays_count integer,
    levels jsonb NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.games OWNER TO iqkids_user;

--
-- Name: login_reward_claims; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.login_reward_claims (
    id character varying(80) NOT NULL,
    user_id character varying(50) NOT NULL,
    claim_date timestamp without time zone NOT NULL,
    day_number integer NOT NULL,
    coin_reward integer NOT NULL
);


ALTER TABLE public.login_reward_claims OWNER TO iqkids_user;

--
-- Name: purchases; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.purchases (
    id integer NOT NULL,
    user_id character varying(50) NOT NULL,
    game_id character varying(80) NOT NULL,
    purchased_price integer,
    purchased_at timestamp without time zone
);


ALTER TABLE public.purchases OWNER TO iqkids_user;

--
-- Name: purchases_id_seq; Type: SEQUENCE; Schema: public; Owner: iqkids_user
--

CREATE SEQUENCE public.purchases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.purchases_id_seq OWNER TO iqkids_user;

--
-- Name: purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: iqkids_user
--

ALTER SEQUENCE public.purchases_id_seq OWNED BY public.purchases.id;


--
-- Name: scratch_courses; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.scratch_courses (
    id character varying(30) NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    thumbnail character varying(20),
    difficulty character varying(50),
    total_lessons integer
);


ALTER TABLE public.scratch_courses OWNER TO iqkids_user;

--
-- Name: scratch_lessons; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.scratch_lessons (
    id integer NOT NULL,
    course_id character varying(30) NOT NULL,
    lesson_num integer NOT NULL,
    title character varying(200) NOT NULL,
    content text,
    target_block_sequence text,
    start_scene_json text,
    xp_reward integer
);


ALTER TABLE public.scratch_lessons OWNER TO iqkids_user;

--
-- Name: scratch_lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: iqkids_user
--

CREATE SEQUENCE public.scratch_lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.scratch_lessons_id_seq OWNER TO iqkids_user;

--
-- Name: scratch_lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: iqkids_user
--

ALTER SEQUENCE public.scratch_lessons_id_seq OWNED BY public.scratch_lessons.id;


--
-- Name: user_achievements; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.user_achievements (
    id character varying(50) NOT NULL,
    user_id character varying(50) NOT NULL,
    achievement_id character varying(30) NOT NULL,
    unlocked_at timestamp without time zone
);


ALTER TABLE public.user_achievements OWNER TO iqkids_user;

--
-- Name: user_daily_quests; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.user_daily_quests (
    id character varying(80) NOT NULL,
    user_id character varying(50) NOT NULL,
    quest_id character varying(50) NOT NULL,
    current_progress integer NOT NULL,
    status character varying(20) NOT NULL,
    quest_date timestamp without time zone NOT NULL
);


ALTER TABLE public.user_daily_quests OWNER TO iqkids_user;

--
-- Name: user_daily_spins; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.user_daily_spins (
    id character varying(80) NOT NULL,
    user_id character varying(50) NOT NULL,
    spin_date timestamp without time zone NOT NULL,
    eligible boolean NOT NULL,
    spun boolean NOT NULL,
    reward_code character varying(40),
    reward_amount integer NOT NULL
);


ALTER TABLE public.user_daily_spins OWNER TO iqkids_user;

--
-- Name: user_scratch_progress; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.user_scratch_progress (
    id character varying(60) NOT NULL,
    user_id character varying(50) NOT NULL,
    course_id character varying(30) NOT NULL,
    lesson_id integer NOT NULL,
    lesson_num integer NOT NULL,
    completed boolean,
    stars_earned integer,
    submitted_sequence text,
    completed_at timestamp without time zone
);


ALTER TABLE public.user_scratch_progress OWNER TO iqkids_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.users (
    id character varying(50) NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255),
    name character varying(150) NOT NULL,
    role character varying(20) NOT NULL,
    grade integer,
    avatar character varying(50),
    xp integer,
    level integer,
    streak integer,
    last_active_date timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO iqkids_user;

--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.wallet_transactions (
    id character varying(50) NOT NULL,
    wallet_user_id character varying(50) NOT NULL,
    amount integer NOT NULL,
    type character varying(50),
    detail character varying(255),
    created_at timestamp without time zone
);


ALTER TABLE public.wallet_transactions OWNER TO iqkids_user;

--
-- Name: wallets; Type: TABLE; Schema: public; Owner: iqkids_user
--

CREATE TABLE public.wallets (
    user_id character varying(50) NOT NULL,
    balance integer,
    currency character varying(10)
);


ALTER TABLE public.wallets OWNER TO iqkids_user;

--
-- Name: purchases id; Type: DEFAULT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.purchases ALTER COLUMN id SET DEFAULT nextval('public.purchases_id_seq'::regclass);


--
-- Name: scratch_lessons id; Type: DEFAULT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.scratch_lessons ALTER COLUMN id SET DEFAULT nextval('public.scratch_lessons_id_seq'::regclass);


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.achievements (id, title, description, badge_code, xp_bonus, icon) FROM stdin;
a1	Nhà Toán Học Nhí	Bứt phá toàn bộ 30 màn Truy Tìm Quy Luật	math_pro	500	🥇
a2	Siêu Trí Nhớ	Vượt qua toàn bộ 30 màn lật thẻ Vua Ghi Nhớ	memory_master	500	🧠
a3	Vua Logic	Hoàn thiện 30 màn rèn tư duy Ghép Cặp	logic_king	500	💡
a4	Lập Trình Viên Tương Lai	Hoàn thành khóa học Scratch cơ bản	scratch_wizard	600	🤖
a5	Thợ Săn Thử Thách	Tham gia giải quyết 3 thử thách liên tiếp hàng ngày	daily_hunter	300	🔥
a6	Nhà Thông Thái Thực Đời	Vượt qua toàn bộ 10 mốc Thử Thách IQ Thực Tế	real_iq_expert	450	🌟
\.


--
-- Data for Name: attempts; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.attempts (id, user_id, game_id, level_num, score, completed, duration_secs, created_at) FROM stdin;
att_seed_1	u1	g1	5	280	t	60	2026-06-22 12:00:00
att_seed_2	u1	g2	2	120	t	60	2026-06-21 11:30:00
att_1788842769401	u1	g_iq_thuc_te	1	15	t	15	2026-09-08 04:46:09.401616
att_1788843028935	u_1788843001195_535a	g3	1	17	t	15	2026-09-08 04:50:28.93515
att_1788843063040	u1	g3	1	17	t	15	2026-09-08 04:51:03.040165
att_1788843068064	u_1788843001195_535a	g3	2	17	t	15	2026-09-08 04:51:08.064449
att_1788843077497	u_1788843001195_535a	g3	3	17	t	15	2026-09-08 04:51:17.497483
att_1788843079282	u1	g3	2	17	t	15	2026-09-08 04:51:19.282207
att_1788843087591	u1	g3	3	17	t	15	2026-09-08 04:51:27.591947
att_1788843098038	u1	g3	4	17	t	15	2026-09-08 04:51:38.038778
att_1788843104674	u1	g3	5	17	t	15	2026-09-08 04:51:44.674833
att_1788843345582	u1	g1	1	12	t	15	2026-09-08 04:55:45.58231
att_1788843383474	u1	g1	2	12	t	15	2026-09-08 04:56:23.474971
att_1788843392709	u1	g1	3	12	t	15	2026-09-08 04:56:32.709889
att_1788843403277	u1	g1	4	12	t	15	2026-09-08 04:56:43.277096
att_1788843415488	u1	g1	5	12	t	15	2026-09-08 04:56:55.488629
att_1788843423578	u1	g1	6	12	t	15	2026-09-08 04:57:03.578933
att_1788843430369	u1	g1	7	12	t	15	2026-09-08 04:57:10.369426
\.


--
-- Data for Name: daily_quests; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.daily_quests (id, title, description, type, target_count, xp_reward, coin_reward, is_active) FROM stdin;
quest_play_count	Chinh phục màn chơi	Hoàn thành 2 màn chơi bất kỳ trong ngày.	play_count	2	50	20	t
quest_score_reach	Điểm số tuyệt đối	Đạt 100 điểm trong một game Toán hoặc IQ.	score_reach	1	75	30	t
quest_scratch_complete	Nhà lập trình nhí	Hoàn thành một bài học Scratch trong ngày.	scratch_complete	1	60	25	t
\.


--
-- Data for Name: game_categories; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.game_categories (code, label, icon, description, sort_order, is_active, created_at) FROM stdin;
iq	Tư Duy IQ Não Bộ	🧠	Rèn luyện tư duy logic, nhận biết hình ảnh và giải đố.	1	t	2026-09-08 04:38:47.795348
math	Toán Học Logic	🔢	Phép tính, dãy số và bài toán tương tác.	2	t	2026-09-08 04:38:47.795353
scratch	Lập Trình Robot Scratch	🐱	Lập trình kéo thả, robot Scratch và STEM.	3	t	2026-09-08 04:38:47.795354
vietnamese	Tiếng Việt & Ngôn Ngữ	📖	Từ vựng, đọc hiểu và ngôn ngữ.	4	t	2026-09-08 04:38:47.795354
\.


--
-- Data for Name: games; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.games (id, title, description, detailed_description, thumbnail, price, grade_from, grade_to, template_code, category, creator_id, creator_name, review_status, review_feedback, is_published, is_seed, rating_avg, plays_count, levels, created_at) FROM stdin;
g1	Ghép Cặp Thần Tốc	Rèn luyện phản xạ nhanh nhạy qua việc nối hình ảnh, phép tính với đáp án đúng.	Chào mừng các nhà thám hiểm nhí! Trong game này, con sẽ được thử thách trí thông minh bằng cách nối các cặp hình ảnh ngộ nghĩnh, từ vựng tiếng Anh bổ ích, và các phép toán diệu kỳ với nhau. Hoàn thành màn chơi thật nhanh để nhận được danh hiệu 'Nhà Toán Học Nhí' và 'Vua Từ Vựng' nhé!	⚡	0	1	3	matching	iq	\N	\N	approved	\N	t	t	4.8	1250	[{"id": "matching_l1", "title": "Màn 1: Khởi đầu", "level_num": 1, "questions": [{"id": "mq_1", "data": {"pairs": [{"left": "Cat 🐱", "right": "Con mèo"}, {"left": "Dog 🐶", "right": "Con chó"}, {"left": "Fish 🐟", "right": "Con cá"}, {"left": "Bird 🐦", "right": "Con chim"}]}, "points": 12, "prompt": "Tiếng Anh con vật siêu vui (Lớp 1 - Màn 1)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l2", "title": "Màn 2: Khởi đầu", "level_num": 2, "questions": [{"id": "mq_2", "data": {"pairs": [{"left": "Sun ☀️", "right": "Mặt trời"}, {"left": "Rain 🌧️", "right": "Cơn mưa"}, {"left": "Wind 💨", "right": "Cơn gió"}, {"left": "Snow ❄️", "right": "Tuyết rơi"}]}, "points": 12, "prompt": "Thời tiết & Thiên nhiên (Lớp 1 - Màn 2)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l3", "title": "Màn 3: Khởi đầu", "level_num": 3, "questions": [{"id": "mq_3", "data": {"pairs": [{"left": "1 + 1", "right": "2"}, {"left": "2 + 1", "right": "3"}, {"left": "3 + 1", "right": "4"}, {"left": "3 + 2", "right": "5"}]}, "points": 12, "prompt": "Phép toán cộng trừ cơ bản (Lớp 1 - Màn 3)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l4", "title": "Màn 4: Khởi đầu", "level_num": 4, "questions": [{"id": "mq_4", "data": {"pairs": [{"left": "Cat 🐱", "right": "Con mèo"}, {"left": "Dog 🐶", "right": "Con chó"}, {"left": "Fish 🐟", "right": "Con cá"}, {"left": "Bird 🐦", "right": "Con chim"}]}, "points": 12, "prompt": "Tiếng Anh con vật siêu vui (Lớp 1 - Màn 4)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l5", "title": "Màn 5: Khởi đầu", "level_num": 5, "questions": [{"id": "mq_5", "data": {"pairs": [{"left": "Sun ☀️", "right": "Mặt trời"}, {"left": "Rain 🌧️", "right": "Cơn mưa"}, {"left": "Wind 💨", "right": "Cơn gió"}, {"left": "Snow ❄️", "right": "Tuyết rơi"}]}, "points": 12, "prompt": "Thời tiết & Thiên nhiên (Lớp 1 - Màn 5)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l6", "title": "Màn 6: Khởi đầu", "level_num": 6, "questions": [{"id": "mq_6", "data": {"pairs": [{"left": "1 + 1", "right": "2"}, {"left": "2 + 1", "right": "3"}, {"left": "3 + 1", "right": "4"}, {"left": "3 + 2", "right": "5"}]}, "points": 12, "prompt": "Phép toán cộng trừ cơ bản (Lớp 1 - Màn 6)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l7", "title": "Màn 7: Khởi đầu", "level_num": 7, "questions": [{"id": "mq_7", "data": {"pairs": [{"left": "Cat 🐱", "right": "Con mèo"}, {"left": "Dog 🐶", "right": "Con chó"}, {"left": "Fish 🐟", "right": "Con cá"}, {"left": "Bird 🐦", "right": "Con chim"}]}, "points": 12, "prompt": "Tiếng Anh con vật siêu vui (Lớp 1 - Màn 7)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l8", "title": "Màn 8: Khởi đầu", "level_num": 8, "questions": [{"id": "mq_8", "data": {"pairs": [{"left": "Sun ☀️", "right": "Mặt trời"}, {"left": "Rain 🌧️", "right": "Cơn mưa"}, {"left": "Wind 💨", "right": "Cơn gió"}, {"left": "Snow ❄️", "right": "Tuyết rơi"}]}, "points": 12, "prompt": "Thời tiết & Thiên nhiên (Lớp 1 - Màn 8)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l9", "title": "Màn 9: Khởi đầu", "level_num": 9, "questions": [{"id": "mq_9", "data": {"pairs": [{"left": "1 + 1", "right": "2"}, {"left": "2 + 1", "right": "3"}, {"left": "3 + 1", "right": "4"}, {"left": "3 + 2", "right": "5"}]}, "points": 12, "prompt": "Phép toán cộng trừ cơ bản (Lớp 1 - Màn 9)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l10", "title": "Màn 10: Khởi đầu", "level_num": 10, "questions": [{"id": "mq_10", "data": {"pairs": [{"left": "Cat 🐱", "right": "Con mèo"}, {"left": "Dog 🐶", "right": "Con chó"}, {"left": "Fish 🐟", "right": "Con cá"}, {"left": "Bird 🐦", "right": "Con chim"}]}, "points": 12, "prompt": "Tiếng Anh con vật siêu vui (Lớp 1 - Màn 10)", "question_type": "matching"}], "xp_reward": 60, "coin_reward": 15}, {"id": "matching_l11", "title": "Màn 11: Thử thách", "level_num": 11, "questions": [{"id": "mq_11", "data": {"pairs": [{"left": "Red 🔴", "right": "Màu đỏ"}, {"left": "Blue 🔵", "right": "Màu xanh dương"}, {"left": "Green 🟢", "right": "Màu xanh lá"}, {"left": "Yellow 🟡", "right": "Màu vàng"}]}, "points": 14, "prompt": "Màu sắc vui nhộn (Lớp 2 - Màn 11)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l12", "title": "Màn 12: Thử thách", "level_num": 12, "questions": [{"id": "mq_12", "data": {"pairs": [{"left": "2 x 3", "right": "6"}, {"left": "5 x 2", "right": "10"}, {"left": "3 x 4", "right": "12"}, {"left": "8 : 2", "right": "4"}]}, "points": 14, "prompt": "Phép nhân phân chia diệu kỳ (Lớp 2 - Màn 12)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l13", "title": "Màn 13: Thử thách", "level_num": 13, "questions": [{"id": "mq_13", "data": {"pairs": [{"left": "Apple 🍎", "right": "Quả táo"}, {"left": "Banana 🍌", "right": "Quả chuối"}, {"left": "Orange 🍊", "right": "Quả cam"}, {"left": "Strawberry 🍓", "right": "Quả dâu"}]}, "points": 14, "prompt": "Từ vựng trái cây tiếng Anh (Lớp 2 - Màn 13)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l14", "title": "Màn 14: Thử thách", "level_num": 14, "questions": [{"id": "mq_14", "data": {"pairs": [{"left": "Red 🔴", "right": "Màu đỏ"}, {"left": "Blue 🔵", "right": "Màu xanh dương"}, {"left": "Green 🟢", "right": "Màu xanh lá"}, {"left": "Yellow 🟡", "right": "Màu vàng"}]}, "points": 14, "prompt": "Màu sắc vui nhộn (Lớp 2 - Màn 14)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l15", "title": "Màn 15: Thử thách", "level_num": 15, "questions": [{"id": "mq_15", "data": {"pairs": [{"left": "2 x 3", "right": "6"}, {"left": "5 x 2", "right": "10"}, {"left": "3 x 4", "right": "12"}, {"left": "8 : 2", "right": "4"}]}, "points": 14, "prompt": "Phép nhân phân chia diệu kỳ (Lớp 2 - Màn 15)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l16", "title": "Màn 16: Thử thách", "level_num": 16, "questions": [{"id": "mq_16", "data": {"pairs": [{"left": "Apple 🍎", "right": "Quả táo"}, {"left": "Banana 🍌", "right": "Quả chuối"}, {"left": "Orange 🍊", "right": "Quả cam"}, {"left": "Strawberry 🍓", "right": "Quả dâu"}]}, "points": 14, "prompt": "Từ vựng trái cây tiếng Anh (Lớp 2 - Màn 16)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l17", "title": "Màn 17: Thử thách", "level_num": 17, "questions": [{"id": "mq_17", "data": {"pairs": [{"left": "Red 🔴", "right": "Màu đỏ"}, {"left": "Blue 🔵", "right": "Màu xanh dương"}, {"left": "Green 🟢", "right": "Màu xanh lá"}, {"left": "Yellow 🟡", "right": "Màu vàng"}]}, "points": 14, "prompt": "Màu sắc vui nhộn (Lớp 2 - Màn 17)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l18", "title": "Màn 18: Thử thách", "level_num": 18, "questions": [{"id": "mq_18", "data": {"pairs": [{"left": "2 x 3", "right": "6"}, {"left": "5 x 2", "right": "10"}, {"left": "3 x 4", "right": "12"}, {"left": "8 : 2", "right": "4"}]}, "points": 14, "prompt": "Phép nhân phân chia diệu kỳ (Lớp 2 - Màn 18)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l19", "title": "Màn 19: Thử thách", "level_num": 19, "questions": [{"id": "mq_19", "data": {"pairs": [{"left": "Apple 🍎", "right": "Quả táo"}, {"left": "Banana 🍌", "right": "Quả chuối"}, {"left": "Orange 🍊", "right": "Quả cam"}, {"left": "Strawberry 🍓", "right": "Quả dâu"}]}, "points": 14, "prompt": "Từ vựng trái cây tiếng Anh (Lớp 2 - Màn 19)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l20", "title": "Màn 20: Thử thách", "level_num": 20, "questions": [{"id": "mq_20", "data": {"pairs": [{"left": "Red 🔴", "right": "Màu đỏ"}, {"left": "Blue 🔵", "right": "Màu xanh dương"}, {"left": "Green 🟢", "right": "Màu xanh lá"}, {"left": "Yellow 🟡", "right": "Màu vàng"}]}, "points": 14, "prompt": "Màu sắc vui nhộn (Lớp 2 - Màn 20)", "question_type": "matching"}], "xp_reward": 70, "coin_reward": 20}, {"id": "matching_l21", "title": "Màn 21: Bản lĩnh", "level_num": 21, "questions": [{"id": "mq_21", "data": {"pairs": [{"left": "Square ⬜", "right": "Hình vuông"}, {"left": "Triangle 🔺", "right": "Hình tam giác"}, {"left": "Circle 🔴", "right": "Hình tròn"}, {"left": "Cube 🧊", "right": "Hình lập phương"}]}, "points": 16, "prompt": "Hình học & Số học phức tạp (Lớp 3 - Màn 21)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l22", "title": "Màn 22: Bản lĩnh", "level_num": 22, "questions": [{"id": "mq_22", "data": {"pairs": [{"left": "Doctor 🧑‍⚕️", "right": "Bác sĩ"}, {"left": "Teacher 🧑‍🏫", "right": "Giáo viên"}, {"left": "Pilot 🧑‍✈️", "right": "Phi công"}, {"left": "Chef 🧑‍🍳", "right": "Đầu bếp"}]}, "points": 16, "prompt": "Nghề nghiệp tiếng Anh (Lớp 3 - Màn 22)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l23", "title": "Màn 23: Bản lĩnh", "level_num": 23, "questions": [{"id": "mq_23", "data": {"pairs": [{"left": "Big (To)", "right": "Small (Nhỏ)"}, {"left": "Fast (Nhanh)", "right": "Slow (Chậm)"}, {"left": "Happy (Vui)", "right": "Sad (Buồn)"}, {"left": "Hot (Nóng)", "right": "Cold (Lạnh)"}]}, "points": 16, "prompt": "Từ trái nghĩa (Lớp 3 - Màn 23)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l24", "title": "Màn 24: Bản lĩnh", "level_num": 24, "questions": [{"id": "mq_24", "data": {"pairs": [{"left": "Square ⬜", "right": "Hình vuông"}, {"left": "Triangle 🔺", "right": "Hình tam giác"}, {"left": "Circle 🔴", "right": "Hình tròn"}, {"left": "Cube 🧊", "right": "Hình lập phương"}]}, "points": 16, "prompt": "Hình học & Số học phức tạp (Lớp 3 - Màn 24)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l25", "title": "Màn 25: Bản lĩnh", "level_num": 25, "questions": [{"id": "mq_25", "data": {"pairs": [{"left": "Doctor 🧑‍⚕️", "right": "Bác sĩ"}, {"left": "Teacher 🧑‍🏫", "right": "Giáo viên"}, {"left": "Pilot 🧑‍✈️", "right": "Phi công"}, {"left": "Chef 🧑‍🍳", "right": "Đầu bếp"}]}, "points": 16, "prompt": "Nghề nghiệp tiếng Anh (Lớp 3 - Màn 25)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l26", "title": "Màn 26: Bản lĩnh", "level_num": 26, "questions": [{"id": "mq_26", "data": {"pairs": [{"left": "Big (To)", "right": "Small (Nhỏ)"}, {"left": "Fast (Nhanh)", "right": "Slow (Chậm)"}, {"left": "Happy (Vui)", "right": "Sad (Buồn)"}, {"left": "Hot (Nóng)", "right": "Cold (Lạnh)"}]}, "points": 16, "prompt": "Từ trái nghĩa (Lớp 3 - Màn 26)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l27", "title": "Màn 27: Bản lĩnh", "level_num": 27, "questions": [{"id": "mq_27", "data": {"pairs": [{"left": "Square ⬜", "right": "Hình vuông"}, {"left": "Triangle 🔺", "right": "Hình tam giác"}, {"left": "Circle 🔴", "right": "Hình tròn"}, {"left": "Cube 🧊", "right": "Hình lập phương"}]}, "points": 16, "prompt": "Hình học & Số học phức tạp (Lớp 3 - Màn 27)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l28", "title": "Màn 28: Bản lĩnh", "level_num": 28, "questions": [{"id": "mq_28", "data": {"pairs": [{"left": "Doctor 🧑‍⚕️", "right": "Bác sĩ"}, {"left": "Teacher 🧑‍🏫", "right": "Giáo viên"}, {"left": "Pilot 🧑‍✈️", "right": "Phi công"}, {"left": "Chef 🧑‍🍳", "right": "Đầu bếp"}]}, "points": 16, "prompt": "Nghề nghiệp tiếng Anh (Lớp 3 - Màn 28)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l29", "title": "Màn 29: Bản lĩnh", "level_num": 29, "questions": [{"id": "mq_29", "data": {"pairs": [{"left": "Big (To)", "right": "Small (Nhỏ)"}, {"left": "Fast (Nhanh)", "right": "Slow (Chậm)"}, {"left": "Happy (Vui)", "right": "Sad (Buồn)"}, {"left": "Hot (Nóng)", "right": "Cold (Lạnh)"}]}, "points": 16, "prompt": "Từ trái nghĩa (Lớp 3 - Màn 29)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}, {"id": "matching_l30", "title": "Màn 30: Bản lĩnh", "level_num": 30, "questions": [{"id": "mq_30", "data": {"pairs": [{"left": "Square ⬜", "right": "Hình vuông"}, {"left": "Triangle 🔺", "right": "Hình tam giác"}, {"left": "Circle 🔴", "right": "Hình tròn"}, {"left": "Cube 🧊", "right": "Hình lập phương"}]}, "points": 16, "prompt": "Hình học & Số học phức tạp (Lớp 3 - Màn 30)", "question_type": "matching"}], "xp_reward": 80, "coin_reward": 25}]	2026-09-08 04:38:43.101032
g2	Truy Tìm Quy Luật	Điền số tiếp theo vào chuỗi quy luật logic. Rèn tư duy toán học toàn diện.	Tìm kiếm mối quan hệ ẩn giấu đằng sau những con số đầy mê hoặc! Trò chơi giúp con rèn luyện tư duy logic, nhận diện chuỗi quy luật và dự đoán xu hướng. Từ đó tăng cường kỹ năng phân tích và rèn luyện vượt trội bán cầu não trái.	🧩	15000	1	3	sequence	math	\N	\N	approved	\N	t	t	4.7	890	[{"id": "sequence_l1", "title": "Màn 1: Quy luật số học", "level_num": 1, "questions": [{"id": "sq_1", "data": {"answer": "5", "sequence": ["1", "2", "3", "4", "?"], "explanation": "Cộng thêm 1 vào số đứng trước."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l2", "title": "Màn 2: Quy luật số học", "level_num": 2, "questions": [{"id": "sq_2", "data": {"answer": "12", "sequence": ["4", "6", "8", "10", "?"], "explanation": "Cộng thêm 2 (quy luật số chẵn)."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l3", "title": "Màn 3: Quy luật số học", "level_num": 3, "questions": [{"id": "sq_3", "data": {"answer": "6", "sequence": ["10", "9", "8", "7", "?"], "explanation": "Bớt đi 1 đơn vị đằng sau."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l4", "title": "Màn 4: Quy luật số học", "level_num": 4, "questions": [{"id": "sq_4", "data": {"answer": "8", "sequence": ["4", "5", "6", "7", "?"], "explanation": "Cộng thêm 1 vào số đứng trước."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l5", "title": "Màn 5: Quy luật số học", "level_num": 5, "questions": [{"id": "sq_5", "data": {"answer": "18", "sequence": ["10", "12", "14", "16", "?"], "explanation": "Cộng thêm 2 (quy luật số chẵn)."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l6", "title": "Màn 6: Quy luật số học", "level_num": 6, "questions": [{"id": "sq_6", "data": {"answer": "6", "sequence": ["10", "9", "8", "7", "?"], "explanation": "Bớt đi 1 đơn vị đằng sau."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l7", "title": "Màn 7: Quy luật số học", "level_num": 7, "questions": [{"id": "sq_7", "data": {"answer": "11", "sequence": ["7", "8", "9", "10", "?"], "explanation": "Cộng thêm 1 vào số đứng trước."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l8", "title": "Màn 8: Quy luật số học", "level_num": 8, "questions": [{"id": "sq_8", "data": {"answer": "24", "sequence": ["16", "18", "20", "22", "?"], "explanation": "Cộng thêm 2 (quy luật số chẵn)."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l9", "title": "Màn 9: Quy luật số học", "level_num": 9, "questions": [{"id": "sq_9", "data": {"answer": "6", "sequence": ["10", "9", "8", "7", "?"], "explanation": "Bớt đi 1 đơn vị đằng sau."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l10", "title": "Màn 10: Quy luật số học", "level_num": 10, "questions": [{"id": "sq_10", "data": {"answer": "14", "sequence": ["10", "11", "12", "13", "?"], "explanation": "Cộng thêm 1 vào số đứng trước."}, "points": 15, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 70, "coin_reward": 17}, {"id": "sequence_l11", "title": "Màn 11: Quy luật số học", "level_num": 11, "questions": [{"id": "sq_11", "data": {"answer": "48", "sequence": ["3", "6", "12", "24", "?"], "explanation": "Nhân đôi số phía trước (gấp 2 lần)."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l12", "title": "Màn 12: Quy luật số học", "level_num": 12, "questions": [{"id": "sq_12", "data": {"answer": "60", "sequence": ["100", "90", "80", "70", "?"], "explanation": "Trừ đi 10 đơn vị ở số đứng trước."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l13", "title": "Màn 13: Quy luật số học", "level_num": 13, "questions": [{"id": "sq_13", "data": {"answer": "85", "sequence": ["65", "70", "75", "80", "?"], "explanation": "Quy luật cộng thêm 5."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l14", "title": "Màn 14: Quy luật số học", "level_num": 14, "questions": [{"id": "sq_14", "data": {"answer": "48", "sequence": ["3", "6", "12", "24", "?"], "explanation": "Nhân đôi số phía trước (gấp 2 lần)."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l15", "title": "Màn 15: Quy luật số học", "level_num": 15, "questions": [{"id": "sq_15", "data": {"answer": "60", "sequence": ["100", "90", "80", "70", "?"], "explanation": "Trừ đi 10 đơn vị ở số đứng trước."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l16", "title": "Màn 16: Quy luật số học", "level_num": 16, "questions": [{"id": "sq_16", "data": {"answer": "100", "sequence": ["80", "85", "90", "95", "?"], "explanation": "Quy luật cộng thêm 5."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l17", "title": "Màn 17: Quy luật số học", "level_num": 17, "questions": [{"id": "sq_17", "data": {"answer": "48", "sequence": ["3", "6", "12", "24", "?"], "explanation": "Nhân đôi số phía trước (gấp 2 lần)."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l18", "title": "Màn 18: Quy luật số học", "level_num": 18, "questions": [{"id": "sq_18", "data": {"answer": "60", "sequence": ["100", "90", "80", "70", "?"], "explanation": "Trừ đi 10 đơn vị ở số đứng trước."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l19", "title": "Màn 19: Quy luật số học", "level_num": 19, "questions": [{"id": "sq_19", "data": {"answer": "115", "sequence": ["95", "100", "105", "110", "?"], "explanation": "Quy luật cộng thêm 5."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l20", "title": "Màn 20: Quy luật số học", "level_num": 20, "questions": [{"id": "sq_20", "data": {"answer": "48", "sequence": ["3", "6", "12", "24", "?"], "explanation": "Nhân đôi số phía trước (gấp 2 lần)."}, "points": 18, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 22}, {"id": "sequence_l21", "title": "Màn 21: Quy luật số học", "level_num": 21, "questions": [{"id": "sq_21", "data": {"answer": "25", "sequence": ["1", "4", "9", "16", "?"], "explanation": "Dãy số chính phương (1x1, 2x2, 3x3, 4x4, 5x5)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l22", "title": "Màn 22: Quy luật số học", "level_num": 22, "questions": [{"id": "sq_22", "data": {"answer": "4", "sequence": ["1", "3", "2", "4", "3", "5", "?"], "explanation": "Cộng 2 rồi trừ 1 xen kẽ (+2, -1, +2, -1)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l23", "title": "Màn 23: Quy luật số học", "level_num": 23, "questions": [{"id": "sq_23", "data": {"answer": "21", "sequence": ["1", "2", "3", "5", "8", "13", "?"], "explanation": "Số tiếp theo là tổng của 2 số liền trước."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l24", "title": "Màn 24: Quy luật số học", "level_num": 24, "questions": [{"id": "sq_24", "data": {"answer": "25", "sequence": ["1", "4", "9", "16", "?"], "explanation": "Dãy số chính phương (1x1, 2x2, 3x3, 4x4, 5x5)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l25", "title": "Màn 25: Quy luật số học", "level_num": 25, "questions": [{"id": "sq_25", "data": {"answer": "4", "sequence": ["1", "3", "2", "4", "3", "5", "?"], "explanation": "Cộng 2 rồi trừ 1 xen kẽ (+2, -1, +2, -1)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l26", "title": "Màn 26: Quy luật số học", "level_num": 26, "questions": [{"id": "sq_26", "data": {"answer": "21", "sequence": ["1", "2", "3", "5", "8", "13", "?"], "explanation": "Số tiếp theo là tổng của 2 số liền trước."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l27", "title": "Màn 27: Quy luật số học", "level_num": 27, "questions": [{"id": "sq_27", "data": {"answer": "25", "sequence": ["1", "4", "9", "16", "?"], "explanation": "Dãy số chính phương (1x1, 2x2, 3x3, 4x4, 5x5)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l28", "title": "Màn 28: Quy luật số học", "level_num": 28, "questions": [{"id": "sq_28", "data": {"answer": "4", "sequence": ["1", "3", "2", "4", "3", "5", "?"], "explanation": "Cộng 2 rồi trừ 1 xen kẽ (+2, -1, +2, -1)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l29", "title": "Màn 29: Quy luật số học", "level_num": 29, "questions": [{"id": "sq_29", "data": {"answer": "21", "sequence": ["1", "2", "3", "5", "8", "13", "?"], "explanation": "Số tiếp theo là tổng của 2 số liền trước."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}, {"id": "sequence_l30", "title": "Màn 30: Quy luật số học", "level_num": 30, "questions": [{"id": "sq_30", "data": {"answer": "25", "sequence": ["1", "4", "9", "16", "?"], "explanation": "Dãy số chính phương (1x1, 2x2, 3x3, 4x4, 5x5)."}, "points": 21, "prompt": "Tìm con số thích hợp điền vào dấu chấm hỏi (?)", "question_type": "sequence"}], "xp_reward": 90, "coin_reward": 27}]	2026-09-08 04:38:43.101037
g3	Vua Ghi Nhớ	Nhớ vị trí lật thẻ hình lộng lẫy để rèn siêu trí tuệ quang học.	Phát triển khả năng tập trung cao độ và rèn lưu giữ trí nhớ ngắn hạn! Trẻ lật các quân bài ngộ nghĩnh, tìm kiếm những cặp hình ảnh giống hệt nhau về chủ đề loài vật, khoa học và trường học. Thử thách tính giờ sinh động thúc đẩy não bộ hoạt động linh hoạt.	🧠	25000	1	3	memory	iq	\N	\N	approved	\N	t	t	4.9	2100	[{"id": "memory_l1", "title": "Màn 1: Sở thú", "level_num": 1, "questions": [{"id": "mq_1", "data": {"items": ["🐱", "🐶"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l2", "title": "Màn 2: Sở thú", "level_num": 2, "questions": [{"id": "mq_2", "data": {"items": ["🐱", "🐶", "🐻"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l3", "title": "Màn 3: Sở thú", "level_num": 3, "questions": [{"id": "mq_3", "data": {"items": ["🐱", "🐶"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l4", "title": "Màn 4: Sở thú", "level_num": 4, "questions": [{"id": "mq_4", "data": {"items": ["🐱", "🐶", "🐻"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l5", "title": "Màn 5: Sở thú", "level_num": 5, "questions": [{"id": "mq_5", "data": {"items": ["🐱", "🐶"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l6", "title": "Màn 6: Sở thú", "level_num": 6, "questions": [{"id": "mq_6", "data": {"items": ["🐱", "🐶", "🐻"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l7", "title": "Màn 7: Sở thú", "level_num": 7, "questions": [{"id": "mq_7", "data": {"items": ["🐱", "🐶"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l8", "title": "Màn 8: Sở thú", "level_num": 8, "questions": [{"id": "mq_8", "data": {"items": ["🐱", "🐶", "🐻"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l9", "title": "Màn 9: Sở thú", "level_num": 9, "questions": [{"id": "mq_9", "data": {"items": ["🐱", "🐶"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l10", "title": "Màn 10: Sở thú", "level_num": 10, "questions": [{"id": "mq_10", "data": {"items": ["🐱", "🐶", "🐻"], "theme": "con_vat"}, "points": 17, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 80, "coin_reward": 20}, {"id": "memory_l11", "title": "Màn 11: Khu vườn", "level_num": 11, "questions": [{"id": "mq_11", "data": {"items": ["🍎", "🍌", "🍇", "🍊"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l12", "title": "Màn 12: Khu vườn", "level_num": 12, "questions": [{"id": "mq_12", "data": {"items": ["🍎", "🍌", "🍇", "🍊", "🍉"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l13", "title": "Màn 13: Khu vườn", "level_num": 13, "questions": [{"id": "mq_13", "data": {"items": ["🍎", "🍌", "🍇", "🍊"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l14", "title": "Màn 14: Khu vườn", "level_num": 14, "questions": [{"id": "mq_14", "data": {"items": ["🍎", "🍌", "🍇", "🍊", "🍉"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l15", "title": "Màn 15: Khu vườn", "level_num": 15, "questions": [{"id": "mq_15", "data": {"items": ["🍎", "🍌", "🍇", "🍊"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l16", "title": "Màn 16: Khu vườn", "level_num": 16, "questions": [{"id": "mq_16", "data": {"items": ["🍎", "🍌", "🍇", "🍊", "🍉"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l17", "title": "Màn 17: Khu vườn", "level_num": 17, "questions": [{"id": "mq_17", "data": {"items": ["🍎", "🍌", "🍇", "🍊"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l18", "title": "Màn 18: Khu vườn", "level_num": 18, "questions": [{"id": "mq_18", "data": {"items": ["🍎", "🍌", "🍇", "🍊", "🍉"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l19", "title": "Màn 19: Khu vườn", "level_num": 19, "questions": [{"id": "mq_19", "data": {"items": ["🍎", "🍌", "🍇", "🍊"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l20", "title": "Màn 20: Khu vườn", "level_num": 20, "questions": [{"id": "mq_20", "data": {"items": ["🍎", "🍌", "🍇", "🍊", "🍉"], "theme": "trai_cay"}, "points": 19, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 90, "coin_reward": 25}, {"id": "memory_l21", "title": "Màn 21: Khoa học", "level_num": 21, "questions": [{"id": "mq_21", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l22", "title": "Màn 22: Khoa học", "level_num": 22, "questions": [{"id": "mq_22", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫", "🚀", "🛸"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l23", "title": "Màn 23: Khoa học", "level_num": 23, "questions": [{"id": "mq_23", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l24", "title": "Màn 24: Khoa học", "level_num": 24, "questions": [{"id": "mq_24", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫", "🚀", "🛸"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l25", "title": "Màn 25: Khoa học", "level_num": 25, "questions": [{"id": "mq_25", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l26", "title": "Màn 26: Khoa học", "level_num": 26, "questions": [{"id": "mq_26", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫", "🚀", "🛸"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l27", "title": "Màn 27: Khoa học", "level_num": 27, "questions": [{"id": "mq_27", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l28", "title": "Màn 28: Khoa học", "level_num": 28, "questions": [{"id": "mq_28", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫", "🚀", "🛸"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l29", "title": "Màn 29: Khoa học", "level_num": 29, "questions": [{"id": "mq_29", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}, {"id": "memory_l30", "title": "Màn 30: Khoa học", "level_num": 30, "questions": [{"id": "mq_30", "data": {"items": ["🎒", "✏️", "📐", "📕", "🎨", "🏫", "🚀", "🛸"], "theme": "truong_hoc"}, "points": 21, "prompt": "Lật các thẻ bài để tìm toàn bộ cặp trùng khớp với nhau!", "question_type": "memory"}], "xp_reward": 100, "coin_reward": 30}]	2026-09-08 04:38:43.101039
g_scratch_studio	Lập Trình Robot Scratch	Lắp ráp các khối thuật toán logic tư duy để chỉ huy phi thuyền hoặc chuyển động chú mèo.	Chào mừng con đến với Studio Lập Trình Robot Scratch cực đỉnh! Tại đây con sẽ được làm quen với tư duy thuật toán máy tính, học cách lắp ghép các khối lệnh tuần tự, vòng lặp lặp lại, hay xoay góc rẽ hướng linh hoạt để dắt đường chú mèo lập trình và chiếc phi thuyền giải quyết 9 thử thách mê cung từ dễ đến nâng cao. Nhận ngay huy hiệu danh giá và hàng trăm XP thưởng nhé!	🤖	0	1	9	memory	scratch	\N	\N	approved	\N	t	t	4.9	2840	[]	2026-09-08 04:38:43.101041
g_iq_thuc_te	Thử Thách IQ Thực Tế	Giải đố các tình huống thực tế đời sống gần gũi giúp phát triển phản xạ nhanh nhạy và tư duy thông thái.	Kho trò chơi thực tế thiết kế riêng để nuôi dưỡng tinh thần khám phá thế giới xung quanh một cách khoa học! Bạn nhỏ sẽ được đặt vào 10 tình huống thực tế sinh động: từ xem giờ đồng hồ bữa cơm gia đình, tính lát bánh cắt sinh nhật, dọn dẹp phân phối đồ ăn thú cưng, đến việc tuân thủ chu kỳ đèn đỏ đèn xanh trên hè phố. Vừa học vừa chơi, tăng tốc phản xạ giải quyết vấn đề!	💡	0	1	5	sequence	iq	\N	\N	approved	\N	t	t	4.95	1420	[{"id": "iq_real_l1", "title": "Dịch chuyển Kim Giờ", "level_num": 1, "questions": [{"id": "iq_real_q1", "data": {"answer": "5 giờ", "options": ["5 giờ", "6 giờ", "12 giờ", "8 giờ"], "sequence": ["1 giờ", "2 giờ", "3 giờ", "4 giờ", "?"], "explanation": "Thời gian trôi xuôi chiều liên tiếp nhau nên sau 4 giờ sẽ đến mốc 5 giờ."}, "points": 15, "prompt": "Sau mỗi tiếng cơm trưa, chiếc kim giờ dịch chuyển thêm 1 nấc mới. Điền mốc tiếp theo hoàn thành quy luật thời gian thực tế!", "question_type": "sequence"}], "xp_reward": 80, "coin_reward": 20}, {"id": "iq_real_l2", "title": "Bánh Ngọt Sinh Nhật", "level_num": 2, "questions": [{"id": "iq_real_q2", "data": {"answer": "8 phần", "options": ["6 phần", "8 phần", "10 phần", "12 phần"], "sequence": ["1 nhát: 2 phần", "2 nhát: 4 phần", "3 nhát: ?"], "explanation": "Mỗi nhát cắt chia đôi không gian vuông góc chéo đối xứng tạo ra cấp số nhân đôi: 2, 4, rồi đến 8 phần bằng nhau."}, "points": 20, "prompt": "Một nhát gập đôi tờ giấy tạo 2 bề bề mặt. Hãy đoán quy luật nhân đôi để biết số phần bánh khi ta dùng 3 đường cắt đối xứng tâm!", "question_type": "sequence"}], "xp_reward": 95, "coin_reward": 25}, {"id": "iq_real_l3", "title": "Bữa Tiệc Thú Cưng", "level_num": 3, "questions": [{"id": "iq_real_q3", "data": {"pairs": [{"left": "Cá 🐟 yêu thích của", "right": "Mèo con 🐱"}, {"left": "Khúc xương 🦴 cho", "right": "Chó cưng 🐶"}, {"left": "Cà rốt 🥕 cho", "right": "Thỏ béo 🐰"}, {"left": "Phô mai thơm 🧀 cho", "right": "Chuột Hamster 🐹"}]}, "points": 25, "prompt": "Bé dọn thức ăn thực tế cho các bạn thú cưng của gia đình. Hãy ghép cặp đúng món ăn được chúng yêu thích nhất!", "question_type": "matching"}], "xp_reward": 90, "coin_reward": 20}, {"id": "iq_real_l4", "title": "Hạ thủy Thuyền Buồm", "level_num": 4, "questions": [{"id": "iq_real_q4", "data": {"answer": "⛵ Đỏ", "options": ["⛵ Đỏ", "⛵ Xanh", "⛵ Vàng", "⛵ Tím"], "sequence": ["⛵ Đỏ", "⛵ Xanh", "⛵ Đỏ", "⛵ Xanh", "?"], "explanation": "Quy luật sắp đặt xen kẽ liên tục hai màu sắc tuần hoàn: Đỏ rồi tới Xanh."}, "points": 15, "prompt": "Đoàn thuyền buồm hạ thủy theo hàng sặc sỡ trên nền cát vàng. Bạn nhỏ hãy dự kiến màu của chiếc thuyền thứ năm!", "question_type": "sequence"}], "xp_reward": 100, "coin_reward": 22}, {"id": "iq_real_l5", "title": "Đèn Giao Thông Đô Thị", "level_num": 5, "questions": [{"id": "iq_real_q5", "data": {"answer": "🟢 Xanh (Đi)", "options": ["🟢 Xanh (Đi)", "🔴 Đỏ (Dừng)", "🟡 Vàng (Chậm)", "🔵 Xanh lam"], "sequence": ["🔴 Đỏ (Dừng)", "🟢 Xanh (Đi)", "🟡 Vàng (Chậm)", "🔴 Đỏ (Dừng)", "?"], "explanation": "Vòng xoay chu kỳ quy chuẩn giao thông luôn là Đỏ chuyển sang Xanh, rồi đến Vàng và lặp lại từ đầu."}, "points": 20, "prompt": "Đèn báo hiệu tự động xoay chuyển trên đường phố. Hãy tìm tín hiệu tiếp theo để người đi bộ dừng hoặc chuẩn bị!", "question_type": "sequence"}], "xp_reward": 100, "coin_reward": 25}, {"id": "iq_real_l6", "title": "Xếp Hàng Đón Xe Bus", "level_num": 6, "questions": [{"id": "iq_real_q6", "data": {"answer": "5. Bạn Nam", "options": ["5. Bạn Nam", "5. Bạn Nữ", "5. Bác Tài Xế", "5. Cô Giáo"], "sequence": ["1. Bạn Nam", "2. Bạn Nữ", "3. Bạn Nam", "4. Bạn Nữ", "?"], "explanation": "Đội ngũ xếp hàng xen kẽ nhịp nhàng tuần hoàn liên tục: Nam -> Nữ -> Nam -> Nữ -> Nam."}, "points": 22, "prompt": "Bé trai và Bé gái xếp hàng trật tự lên xe dã ngoại. Hãy đoán xem vị trí thứ năm là bạn Nam hay Nữ?", "question_type": "sequence"}], "xp_reward": 110, "coin_reward": 25}, {"id": "iq_real_l7", "title": "Dấu tích Lốp Xe trên sân", "level_num": 7, "questions": [{"id": "iq_real_q7", "data": {"pairs": [{"left": "Xe đạp 🚲 tạo", "right": "1 vệt lốp mỏng dẹt"}, {"left": "Xe máy điện 🏍️ tạo", "right": "1 vệt lốp dày có gai sâu"}, {"left": "Xe ô tô con 🚗 tạo", "right": "2 vệt lốp song song cỡ vừa"}, {"left": "Xe máy cày 🚜 tạo", "right": "2 vệt lốp khổng lồ gai răng cưa"}]}, "points": 25, "prompt": "Tìm dấu vết lốp xe in hằn trên nền cát ẩm để phá án truy vết phương tiện giao thông đời thường nhé!", "question_type": "matching"}], "xp_reward": 120, "coin_reward": 30}, {"id": "iq_real_l8", "title": "Tước vị Thờ Gian dã ngoại", "level_num": 8, "questions": [{"id": "iq_real_q8", "data": {"answer": "Tháng 9", "options": ["Tháng 8", "Tháng 9", "Tháng 10", "Tháng 11"], "sequence": ["Tháng 1", "Tháng 3", "Tháng 5", "Tháng 7", "?"], "explanation": "Cứ cách 2 tháng trường sẽ đi chơi dã ngoại 1 lần (dãy số tăng cách đều +2 đơn vị lẻ)."}, "points": 20, "prompt": "Các tháng đi dã ngoại của trường cách đều nhau 2 tháng (Tháng lẻ). Hãy tìm kỳ dã ngoại kế tiếp!", "question_type": "sequence"}], "xp_reward": 115, "coin_reward": 28}, {"id": "iq_real_l9", "title": "Chỉ số Rót Nước ngọt", "level_num": 9, "questions": [{"id": "iq_real_q9", "data": {"answer": "1000 ml", "options": ["800 ml", "900 ml", "1000 ml", "1200 ml"], "sequence": ["250 ml", "500 ml", "750 ml", "?"], "explanation": "Lượng nước tăng dần đều 250ml sau mỗi lần rót dồn (250 -> 500 -> 750 -> 1000ml)."}, "points": 25, "prompt": "Lượng nước được rót đầy bình tăng tiến đều đặn qua mỗi bữa giải khát. Hãy tìm nấc can nước cuối cùng!", "question_type": "sequence"}], "xp_reward": 125, "coin_reward": 30}, {"id": "iq_real_l10", "title": "Nhà thông thái Phân Loại Rác", "level_num": 10, "questions": [{"id": "iq_real_q10", "data": {"pairs": [{"left": "Vỏ chuối, rau thừa 🌽 ném vào", "right": "Thùng Rác Hữu Cơ 🍏"}, {"left": "Chai nhựa, vỏ lon 🥤 ném vào", "right": "Thùng Rác Tái Chế 🔄"}, {"left": "Pin hỏng, bóng đèn 🔋 ném vào", "right": "Thùng Rác Nguy Hại ⚠️"}, {"left": "Túi bóng cũ bẩn và sành sứ ném vào", "right": "Thùng Rác Còn Lại 🗑️"}]}, "points": 30, "prompt": "Hãy giúp thành phố xanh tươi sạch đẹp bằng cách ghép rác sinh hoạt đời sống vào đúng thùng phân loại!", "question_type": "matching"}], "xp_reward": 150, "coin_reward": 40}]	2026-09-08 04:38:43.101043
\.


--
-- Data for Name: login_reward_claims; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.login_reward_claims (id, user_id, claim_date, day_number, coin_reward) FROM stdin;
\.


--
-- Data for Name: purchases; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.purchases (id, user_id, game_id, purchased_price, purchased_at) FROM stdin;
1	u1	g1	0	2026-09-08 04:38:43.112696
2	u2	g1	0	2026-09-08 04:38:43.1127
3	u2	g2	0	2026-09-08 04:38:43.1127
4	u2	g3	0	2026-09-08 04:38:43.112701
5	u3	g1	0	2026-09-08 04:38:43.112701
6	u3	g2	0	2026-09-08 04:38:43.112702
7	u_1788843001195_535a	g1	0	2026-09-08 04:50:01.589516
\.


--
-- Data for Name: scratch_courses; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.scratch_courses (id, title, description, thumbnail, difficulty, total_lessons) FROM stdin;
sc1	Chinh phục Scratch Tinh Vân	Nhập môn lập trình kéo thả Scratch bằng cách điều khiển tàu phi thuyền phiêu lưu trong vũ trụ.	🚀	Cơ bản	5
sc2	Khám Phá Mê Cung Thuật Toán	Nâng cao tư duy không gian và giải thuật toán rẽ nhánh cơ bản với các mê cung lắt léo hơn.	🌀	Nâng cao	4
\.


--
-- Data for Name: scratch_lessons; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.scratch_lessons (id, course_id, lesson_num, title, content, target_block_sequence, start_scene_json, xp_reward) FROM stdin;
1	sc1	1	Khởi Động Động Cơ	Giúp chú mèo Scratch tiến về tinh vân lấp lánh bằng cách sử dụng khối lệnh 'Di chuyển'.	move_forward,move_forward	{"cat_pos":[0,2],"star_pos":[2,2]}	100
2	sc1	2	Bẻ Lái Tránh Chướng Ngại Vật	Để tránh đám mây bụi vũ trụ, hãy điều khiển chú mèo rẽ phải trước khi đi tiếp.	move_forward,turn_right,move_forward	{"cat_pos":[0,1],"star_pos":[1,2]}	120
3	sc1	3	Chu Kỳ Lặp Vô Tận	Sử dụng khối 'Vòng lặp' để mèo tự động di chuyển 3 bước mà không cần nối nhiều khối.	repeat_3[move_forward]	{"cat_pos":[0,0],"star_pos":[3,0]}	150
4	sc1	4	Vượt Trọng Lực Vũ Trụ	Hãy xoay người hướng lên trên (Quay trái) và kích hoạt vòng lặp 3 lần di chuyển để tiến đến ngôi sao lấp lánh ở (1,0)!	turn_left,repeat_3[move_forward]	{"cat_pos":[1,3],"star_pos":[1,0]}	180
5	sc1	5	Hành Trình Vòng Cung	Tiến lên 2 bước, rẽ phải và tiến thêm 2 bước nữa để thu thập ngôi sao năng lượng tại tọa độ tinh vân (2,2)!	move_forward,move_forward,turn_right,move_forward,move_forward	{"cat_pos":[0,0],"star_pos":[2,2]}	200
6	sc2	1	Quay Đầu Đi Tìm Sao	Ngôi sao ở ngay phía sau con tại (0,1). Hãy xoay chú mèo quay ngược lại (Quay trái 2 lần) và tiến lên 2 bước!	turn_left,turn_left,move_forward,move_forward	{"cat_pos":[2,1],"star_pos":[0,1]}	220
7	sc2	2	Bám Sát Rìa Vũ Trụ	Sử dụng vòng lặp 3 lần di chuyển liên tiếp để đi dọc rìa trên cùng đến (3,0), sau đó rẽ phải và tiến thêm 1 bước xuống (3,1)!	repeat_3[move_forward],turn_right,move_forward	{"cat_pos":[0,0],"star_pos":[3,1]}	250
8	sc2	3	Đường Đi Zích Zắc	Kiểm soát bước đi zích zắc thông minh: Tiến, rẽ trái, tiến, rẽ phải, tiến, rẽ trái, tiến để thu hoạch sao rực rỡ tại tọa độ (2,0)!	move_forward,turn_left,move_forward,turn_right,move_forward,turn_left,move_forward	{"cat_pos":[0,2],"star_pos":[2,0]}	280
9	sc2	4	Lùi Lại Về Đích	Từ góc phải bên dưới (3,3), hãy quay đầu hoàn toàn sang trái (Quay trái 2 lần) và dùng siêu vòng lặp để lướt thẳng về đích tại (0,3)!	turn_left,turn_left,repeat_3[move_forward]	{"cat_pos":[3,3],"star_pos":[0,3]}	300
\.


--
-- Data for Name: user_achievements; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.user_achievements (id, user_id, achievement_id, unlocked_at) FROM stdin;
ua_u1_a5_1788842769495	u1	a5	2026-09-08 04:46:09.495798
\.


--
-- Data for Name: user_daily_quests; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.user_daily_quests (id, user_id, quest_id, current_progress, status, quest_date) FROM stdin;
udq_u1_quest_score_reach_2026-09-08	u1	quest_score_reach	0	IN_PROGRESS	2026-09-08 00:00:00
udq_u_1788843001195_535a_quest_score_reach_2026-09-08	u_1788843001195_535a	quest_score_reach	0	IN_PROGRESS	2026-09-08 00:00:00
udq_u_1788843001195_535a_quest_scratch_complete_2026-09-08	u_1788843001195_535a	quest_scratch_complete	0	IN_PROGRESS	2026-09-08 00:00:00
udq_u1_quest_play_count_2026-09-08	u1	quest_play_count	2	COMPLETED	2026-09-08 00:00:00
udq_u_1788843001195_535a_quest_play_count_2026-09-08	u_1788843001195_535a	quest_play_count	2	COMPLETED	2026-09-08 00:00:00
udq_u1_quest_scratch_complete_2026-09-08	u1	quest_scratch_complete	1	COMPLETED	2026-09-08 00:00:00
\.


--
-- Data for Name: user_daily_spins; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.user_daily_spins (id, user_id, spin_date, eligible, spun, reward_code, reward_amount) FROM stdin;
spin_u1_2026-09-08	u1	2026-09-08 00:00:00	t	f	\N	0
spin_u_1788843001195_535a_2026-09-08	u_1788843001195_535a	2026-09-08 00:00:00	t	f	\N	0
\.


--
-- Data for Name: user_scratch_progress; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.user_scratch_progress (id, user_id, course_id, lesson_id, lesson_num, completed, stars_earned, submitted_sequence, completed_at) FROM stdin;
usp_u1_sc1_1_1788843218763	u1	sc1	1	1	t	3	move_forward,move_forward	2026-09-08 04:53:38.762449
usp_u1_sc1_2_1788843468825	u1	sc1	2	2	t	3	move_forward,turn_right,move_forward	2026-09-08 04:58:02.679992
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.users (id, username, password_hash, name, role, grade, avatar, xp, level, streak, last_active_date, created_at) FROM stdin;
u2	giao_vien_lan	$2b$12$1R7Z2pton/ykJRRLLYk4zuxyTYEkHYFXr7vu.Ec81R7SPXqnkI7QO	Cô Lan Anh 👩‍🏫	teacher	\N	logic_owl	450	5	0	\N	2026-09-08 04:38:43.051574
u3	kid_dung	$2b$12$S29eKDnyEpJ1bFezR4PSaezvBZB1v9cIdsBYEYT3OYH7/OPBEmgXW	Minh Dũng 🦊	student	3	cool_fox	80	1	1	\N	2026-09-08 04:38:43.051576
u_admin	admin	$2b$12$Z6TEmRjA4OFmQsO8OPOETe7mnAG6ZjR5UXkqdSNKFaFvsDINvqcze	Ban Quản Trị 🛡️	admin	\N	brave_dragon	0	1	0	\N	2026-09-08 04:38:43.051578
u_1788843001195_535a	kid_annhien	$2b$12$lkzgEh0ynKLiTP.ZyHaQ7uBJSFQU1gsQAfwOt.Jhp8iI1L/Whx7iC	An Nhiên	student	2	smile_tiger	100	1	1	2026-09-08 04:51:17.497483	2026-09-08 04:50:01.581091
u1	kid_binh	$2b$12$S7szcuOr5m3vW516FdiZeOazmXRsag/UoSAUILILmyE8j47jt1qGK	Thế Bình 🌟	student	2	smile_tiger	880	2	3	2026-09-08 04:57:10.369426	2026-09-08 04:38:43.051568
\.


--
-- Data for Name: wallet_transactions; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.wallet_transactions (id, wallet_user_id, amount, type, detail, created_at) FROM stdin;
tx_1	u1	90000	nạp tiền	Được tặng ban đầu	2026-06-22 10:00:00
tx_2	u2	500000	nạp tiền	Nạp qua QR	2026-06-22 08:00:00
tx_3	u3	1000000	nạp tiền	Được tặng ban đầu	2026-06-22 07:15:00
tx_1788843001586	u_1788843001195_535a	90000	nạp tiền	Quà tặng khởi tạo tài khoản IQ Kid Market ✨	2026-09-08 04:50:01.595973
tx_scratch_1788843218788	u1	10	thưởng chơi game	Thưởng hoàn thành bài học Scratch: "Khởi Động Động Cơ" (+10 xu)	2026-09-08 04:53:38.762449
tx_scratch_1788843468844	u1	10	thưởng chơi game	Thưởng hoàn thành bài học Scratch: "Bẻ Lái Tránh Chướng Ngại Vật" (+10 xu)	2026-09-08 04:57:48.824522
tx_scratch_1788843476875	u1	10	thưởng chơi game	Thưởng hoàn thành bài học Scratch: "Bẻ Lái Tránh Chướng Ngại Vật" (+10 xu)	2026-09-08 04:57:56.872367
tx_scratch_1788843482683	u1	10	thưởng chơi game	Thưởng hoàn thành bài học Scratch: "Bẻ Lái Tránh Chướng Ngại Vật" (+10 xu)	2026-09-08 04:58:02.679992
\.


--
-- Data for Name: wallets; Type: TABLE DATA; Schema: public; Owner: iqkids_user
--

COPY public.wallets (user_id, balance, currency) FROM stdin;
u2	500000	VND
u3	1000000	VND
u_admin	0	VND
u_1788843001195_535a	90000	VND
u1	90040	VND
\.


--
-- Name: purchases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: iqkids_user
--

SELECT pg_catalog.setval('public.purchases_id_seq', 7, true);


--
-- Name: scratch_lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: iqkids_user
--

SELECT pg_catalog.setval('public.scratch_lessons_id_seq', 9, true);


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: attempts attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_pkey PRIMARY KEY (id);


--
-- Name: daily_quests daily_quests_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.daily_quests
    ADD CONSTRAINT daily_quests_pkey PRIMARY KEY (id);


--
-- Name: game_categories game_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.game_categories
    ADD CONSTRAINT game_categories_pkey PRIMARY KEY (code);


--
-- Name: games games_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_pkey PRIMARY KEY (id);


--
-- Name: login_reward_claims login_reward_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.login_reward_claims
    ADD CONSTRAINT login_reward_claims_pkey PRIMARY KEY (id);


--
-- Name: purchases purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_pkey PRIMARY KEY (id);


--
-- Name: scratch_courses scratch_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.scratch_courses
    ADD CONSTRAINT scratch_courses_pkey PRIMARY KEY (id);


--
-- Name: scratch_lessons scratch_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.scratch_lessons
    ADD CONSTRAINT scratch_lessons_pkey PRIMARY KEY (id);


--
-- Name: login_reward_claims uq_login_reward_user_day; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.login_reward_claims
    ADD CONSTRAINT uq_login_reward_user_day UNIQUE (user_id, claim_date);


--
-- Name: user_daily_quests uq_user_daily_quest_day; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_quests
    ADD CONSTRAINT uq_user_daily_quest_day UNIQUE (user_id, quest_id, quest_date);


--
-- Name: user_daily_spins uq_user_daily_spin_day; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_spins
    ADD CONSTRAINT uq_user_daily_spin_day UNIQUE (user_id, spin_date);


--
-- Name: user_achievements user_achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_pkey PRIMARY KEY (id);


--
-- Name: user_daily_quests user_daily_quests_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_quests
    ADD CONSTRAINT user_daily_quests_pkey PRIMARY KEY (id);


--
-- Name: user_daily_spins user_daily_spins_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_spins
    ADD CONSTRAINT user_daily_spins_pkey PRIMARY KEY (id);


--
-- Name: user_scratch_progress user_scratch_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_scratch_progress
    ADD CONSTRAINT user_scratch_progress_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (user_id);


--
-- Name: ix_attempts_created_at; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_attempts_created_at ON public.attempts USING btree (created_at);


--
-- Name: ix_attempts_game_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_attempts_game_id ON public.attempts USING btree (game_id);


--
-- Name: ix_attempts_score; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_attempts_score ON public.attempts USING btree (score);


--
-- Name: ix_attempts_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_attempts_user_id ON public.attempts USING btree (user_id);


--
-- Name: ix_daily_quests_type; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE UNIQUE INDEX ix_daily_quests_type ON public.daily_quests USING btree (type);


--
-- Name: ix_game_categories_is_active; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_game_categories_is_active ON public.game_categories USING btree (is_active);


--
-- Name: ix_game_categories_sort_order; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_game_categories_sort_order ON public.game_categories USING btree (sort_order);


--
-- Name: ix_games_category; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_category ON public.games USING btree (category);


--
-- Name: ix_games_created_at; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_created_at ON public.games USING btree (created_at);


--
-- Name: ix_games_creator_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_creator_id ON public.games USING btree (creator_id);


--
-- Name: ix_games_grade_from; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_grade_from ON public.games USING btree (grade_from);


--
-- Name: ix_games_grade_to; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_grade_to ON public.games USING btree (grade_to);


--
-- Name: ix_games_is_published; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_is_published ON public.games USING btree (is_published);


--
-- Name: ix_games_price; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_price ON public.games USING btree (price);


--
-- Name: ix_games_rating_avg; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_rating_avg ON public.games USING btree (rating_avg);


--
-- Name: ix_games_review_status; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_review_status ON public.games USING btree (review_status);


--
-- Name: ix_games_template_code; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_games_template_code ON public.games USING btree (template_code);


--
-- Name: ix_login_reward_claims_claim_date; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_login_reward_claims_claim_date ON public.login_reward_claims USING btree (claim_date);


--
-- Name: ix_login_reward_claims_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_login_reward_claims_user_id ON public.login_reward_claims USING btree (user_id);


--
-- Name: ix_purchases_game_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_purchases_game_id ON public.purchases USING btree (game_id);


--
-- Name: ix_purchases_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_purchases_user_id ON public.purchases USING btree (user_id);


--
-- Name: ix_user_achievements_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_achievements_user_id ON public.user_achievements USING btree (user_id);


--
-- Name: ix_user_daily_quests_quest_date; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_daily_quests_quest_date ON public.user_daily_quests USING btree (quest_date);


--
-- Name: ix_user_daily_quests_quest_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_daily_quests_quest_id ON public.user_daily_quests USING btree (quest_id);


--
-- Name: ix_user_daily_quests_status; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_daily_quests_status ON public.user_daily_quests USING btree (status);


--
-- Name: ix_user_daily_quests_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_daily_quests_user_id ON public.user_daily_quests USING btree (user_id);


--
-- Name: ix_user_daily_spins_spin_date; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_daily_spins_spin_date ON public.user_daily_spins USING btree (spin_date);


--
-- Name: ix_user_daily_spins_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_daily_spins_user_id ON public.user_daily_spins USING btree (user_id);


--
-- Name: ix_user_scratch_progress_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_user_scratch_progress_user_id ON public.user_scratch_progress USING btree (user_id);


--
-- Name: ix_users_grade; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_users_grade ON public.users USING btree (grade);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: ix_users_streak; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_users_streak ON public.users USING btree (streak);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_users_xp; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_users_xp ON public.users USING btree (xp);


--
-- Name: ix_wallet_transactions_created_at; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_wallet_transactions_created_at ON public.wallet_transactions USING btree (created_at);


--
-- Name: ix_wallet_transactions_wallet_user_id; Type: INDEX; Schema: public; Owner: iqkids_user
--

CREATE INDEX ix_wallet_transactions_wallet_user_id ON public.wallet_transactions USING btree (wallet_user_id);


--
-- Name: attempts attempts_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.games(id) ON DELETE CASCADE;


--
-- Name: attempts attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: games games_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.games
    ADD CONSTRAINT games_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: login_reward_claims login_reward_claims_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.login_reward_claims
    ADD CONSTRAINT login_reward_claims_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.games(id) ON DELETE CASCADE;


--
-- Name: purchases purchases_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.purchases
    ADD CONSTRAINT purchases_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scratch_lessons scratch_lessons_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.scratch_lessons
    ADD CONSTRAINT scratch_lessons_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.scratch_courses(id) ON DELETE CASCADE;


--
-- Name: user_achievements user_achievements_achievement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_achievement_id_fkey FOREIGN KEY (achievement_id) REFERENCES public.achievements(id) ON DELETE CASCADE;


--
-- Name: user_achievements user_achievements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_achievements
    ADD CONSTRAINT user_achievements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_daily_quests user_daily_quests_quest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_quests
    ADD CONSTRAINT user_daily_quests_quest_id_fkey FOREIGN KEY (quest_id) REFERENCES public.daily_quests(id) ON DELETE CASCADE;


--
-- Name: user_daily_quests user_daily_quests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_quests
    ADD CONSTRAINT user_daily_quests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_daily_spins user_daily_spins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_daily_spins
    ADD CONSTRAINT user_daily_spins_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_scratch_progress user_scratch_progress_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_scratch_progress
    ADD CONSTRAINT user_scratch_progress_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.scratch_courses(id) ON DELETE CASCADE;


--
-- Name: user_scratch_progress user_scratch_progress_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_scratch_progress
    ADD CONSTRAINT user_scratch_progress_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.scratch_lessons(id) ON DELETE CASCADE;


--
-- Name: user_scratch_progress user_scratch_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.user_scratch_progress
    ADD CONSTRAINT user_scratch_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: wallet_transactions wallet_transactions_wallet_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_wallet_user_id_fkey FOREIGN KEY (wallet_user_id) REFERENCES public.wallets(user_id) ON DELETE CASCADE;


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: iqkids_user
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Okuj8ch3Fc91wzfoGuhnA3KHpajAsTbN0b2ORYJCo8Cs62sngQhBp3f3J050SV4

